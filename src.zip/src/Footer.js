import React from 'react';
const Footer = () => {
 return <footer>© 2024 My Website</footer>;
};
export default Footer;