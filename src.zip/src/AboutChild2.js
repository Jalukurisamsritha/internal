import React from 'react';
const AboutChild2 = () => {
 return <div>About Child 2 Content</div>;
};
export default AboutChild2;