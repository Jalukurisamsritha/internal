import React from 'react';
const AboutChild1 = () => {
 return <div>About Child 1 Content</div>;
};
export default AboutChild1;