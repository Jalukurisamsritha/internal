import React from 'react';
const HomeChild2 = () => {
 return <div>Home Child 2 Content</div>;
};
export default HomeChild2;