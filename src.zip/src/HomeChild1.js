import React from 'react';
const HomeChild1 = () => {
 return <div>Home Child 1 Content</div>;
};
export default HomeChild1;